$("document").ready(function(){
	function ToTop() {
		let button = $('.to-top');
	
	
		$(window).on('scroll', () =>{
			if ($(this).scrollTop() >= 50){
				button.fadeIn();
			} else{
				button.fadeOut();
			}
		});
	
	
		button.on('click', (e) => {
			e.preventDefault();
			$('html').animate({scrollTop: 0}, 1000);
		})
	}
	ToTop();

	var bunner = $(".name2");
	bunner.waypoint(function (direction){
		if (direction == 'down') {
			bunner.addClass("active")
		}
	},{offset:'60%'})
	// $('.name2').waypoint(function(){
	// 	$('.name2').addClass('animating zoomIn')	
	// }, {
	// 	offset: '5%'
	// });
});


